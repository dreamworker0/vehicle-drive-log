# 알리고 브랜드 메시지 API - Node.js

PHP 예제 코드를 Node.js로 변환한 버전입니다.

## 설치

```bash
npm install
```

## 파일 구조

```
├── aligo_brand_class.js          # 메인 클래스
├── aligo_brand_send.js           # 브랜드 메시지 전송 예제
├── aligo_brand_template_create.js # 템플릿 생성 예제
├── aligo_brand_template_list.js  # 템플릿 목록 조회 예제
├── package.json
└── README.md
```

## 사용법

### 1. 브랜드 메시지 전송

```bash
npm run send
```

또는

```javascript
const AligoBrandClass = require('./aligo_brand_class');
const brand = new AligoBrandClass();

const result = await brand.send_brand_message({
    'userid': '알리고 계정 아이디',
    'apikey': '알리고 API 키',
    'template_code': '생성된 브랜드 템플릿 코드',
    'sender': '발신번호',
    'kakao_target': 'N',
    'receiver_1': '수신자 휴대폰 번호',
    'receiver_1_message': {
        '#{헤더링크}': 'smartsms.aligo.in',
        '#{인삿말}': '안녕하세요'
    },
    'failoverYn': 'Y',
    'failover_type': 'MMS',
    'failover_subject1': '실패시 제목 문자',
    'failover_content1': '실패시 내용 문자'
}, {
    'failover_mms1': '800x400.jpg'
});
```

### 2. 템플릿 목록 조회

```bash
npm run template:list
```

### 3. 템플릿 생성

```bash
npm run template:create
```

## 주의사항

- `form-data` 패키지가 필요합니다 (`npm install form-data`)
- 파일 업로드 시 파일 경로를 지정합니다
- 모든 API 호출은 비동기(async/await)로 처리됩니다
