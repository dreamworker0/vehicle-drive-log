/**
 * 등록한 브랜드 메시지 템플릿 조회 예제
 */

// 클래스 참조
const AligoBrandClass = require('./aligo_brand_class');

// 클래스 로드
const brand = new AligoBrandClass();

// 등록한 브랜드 메시지 템플릿 조회
(async () => {
    try {
        const result = await brand.list_template({
            'userid': '알리고 계정 아이디',
            'apikey': '알리고 API 키',
            'senderkey': '카카오 채널 키',
            'page': 1,
            'pageSize': 200
        });

        console.log('Content-Type: application/json');
        console.log(result);
    } catch (error) {
        console.error('Error:', error);
    }
})();
