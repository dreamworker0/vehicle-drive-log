/**
 * 알리고 브랜드 메시지 연동 예제
 */

const fs = require('fs');
const path = require('path');
const FormData = require('form-data');
const https = require('https');
const http = require('http');

class AligoBrandClass {
    constructor() {
        this.set_api_url = 'https://kakaoapi.aligo.in';
    }

    /**
     * 브랜드 메시지 전송
     * @param {Object} params
     * @param {Object} files
     * @returns {Promise<string>}
     */
    async send_brand_message(params = {}, files = {}) {
        // 배열 파라메더 정리
        for (const _key in params) {
            if (typeof params[_key] === 'object' && params[_key] !== null) {
                params[_key] = JSON.stringify(params[_key]);
            }
        }

        // 결과 반환
        return await this.sendCurl('/brandtalk/template/send/', params, files);
    }

    /**
     * 생성한 템플릿의 목록을 조회 합니다.
     * @param {Object} params
     * @returns {Promise<string>}
     */
    async list_template(params = {}) {
        return await this.sendCurl('/brandtalk/template/list/', params);
    }

    /**
     * 템플릿을 생성합니다.
     * @param {Object} params
     * @param {Object} files
     * @returns {Promise<string>}
     */
    async create_template(params = {}, files = {}) {
        // 배열 파라메더 정리
        for (const _key in params) {
            if (typeof params[_key] === 'object' && params[_key] !== null) {
                params[_key] = JSON.stringify(params[_key]);
            }
        }

        // 반환
        return await this.sendCurl('/brandtalk/template/create/', params, files);
    }

    /**
     * cURL 데이터 전송 요청
     * @param {string} set_api_path
     * @param {Object} set_post_data
     * @param {Object} set_file_data
     * @param {Object} set_header
     * @param {Object} set_options
     * @returns {Promise<string>}
     */
    async sendCurl(set_api_path = '', set_post_data = {}, set_file_data = {}, set_header = {}, set_options = {}) {
        // 경로 구분자를 누락했을 경우 체크
        let apiUrl = this.set_api_url;
        if (!set_api_path.startsWith('/')) {
            apiUrl = apiUrl + '/';
        }

        const formData = new FormData();

        // POST 데이터 추가
        for (const _key in set_post_data) {
            formData.append(_key, set_post_data[_key]);
        }

        // 파일 파라메더 설정
        for (const _key in set_file_data) {
            const _val = set_file_data[_key];
            
            if (typeof _val === 'string') {
                // 파일 경로인 경우
                const filePath = _val;
                const fileName = path.basename(filePath);
                formData.append(_key, fs.createReadStream(filePath), {
                    filename: fileName
                });
            } else if (_val && _val.tmp_name) {
                // tmp_name이 있는 객체인 경우 (PHP $_FILES 형태)
                formData.append(_key, fs.createReadStream(_val.tmp_name), {
                    filename: _val.name,
                    contentType: _val.type
                });
            }
        }

        return new Promise((resolve, reject) => {
            const url = new URL(apiUrl + set_api_path);
            const protocol = url.protocol === 'https:' ? https : http;

            const options = {
                hostname: url.hostname,
                port: url.port || (url.protocol === 'https:' ? 443 : 80),
                path: url.pathname + url.search,
                method: 'POST',
                headers: {
                    ...formData.getHeaders(),
                    'User-Agent': 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.0.3705; .NET CLR 1.1.4322)',
                    ...set_header
                },
                timeout: 30000,
                rejectUnauthorized: false // SSL_VERIFYPEER = FALSE
            };

            // 추가 옵션 설정
            for (const _key in set_options) {
                options[_key] = set_options[_key];
            }

            const req = protocol.request(options, (res) => {
                let data = '';
                res.on('data', (chunk) => {
                    data += chunk;
                });
                res.on('end', () => {
                    resolve(data);
                });
            });

            req.on('error', (error) => {
                reject(error);
            });

            req.on('timeout', () => {
                req.destroy();
                reject(new Error('Request timeout'));
            });

            formData.pipe(req);
        });
    }
}

module.exports = AligoBrandClass;
