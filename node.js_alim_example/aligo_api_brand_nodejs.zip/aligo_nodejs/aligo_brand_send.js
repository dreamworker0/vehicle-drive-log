/**
 * 브랜드 메시지 발송 예제
 */

// 클래스 참조
const AligoBrandClass = require('./aligo_brand_class');

// 클래스 로드
const brand = new AligoBrandClass();

// 브랜드 메시지 발송
(async () => {
    try {
        const result = await brand.send_brand_message({
            'userid': '알리고 계정 아이디',
            'apikey': '알리고 API 키',
            'template_code': '생성된 브랜드 템플릿 코드',
            // 'senddate': formatDate(new Date(Date.now() + 30 * 60 * 1000)), // 예약발송일 경우 사용
            'sender': '대체문자 사용시 알리고에 등록된 발신번호',
            'kakao_target': 'N', // N : 비친구, I : 친구, M : 비친구 전송 후 실패 메시지만 친구 타입으로 재전송
            'receiver_1': '수신자 휴대폰 번호',
            'receiver_1_message': {  // 템플릿 목록 조회 템플릿에서 노출되는 send_variable 값 입니다. 치환자가 없을 경우 빈값 입니다
                '#{헤더링크}': 'smartsms.aligo.in',
                '#{인삿말}': '안녕하세요'
            },
            'failoverYn': 'Y', // 실패한 메시지에 대하여 대체문자를 보낼 경우 Y 입니다.
            'failover_type': 'MMS', // SMS, LMS, MMS 중 한개 입니다
            'failover_subject1': '실패시 제목 문자',
            'failover_content1': '실패시 내용 문자\n줄바꿈 테스트'
        }, {
            'failover_mms1': '800x400.jpg',
            'failover_mms2': '800x600.jpg',
            'failover_mms3': '800x800.jpg'
        });

        console.log('Content-Type: application/json');
        console.log(result);
    } catch (error) {
        console.error('Error:', error);
    }
})();

/**
 * 날짜를 YYYYMMDDHHmm00 형식으로 변환
 * @param {Date} date
 * @returns {string}
 */
function formatDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    return `${year}${month}${day}${hours}${minutes}00`;
}
