/**
 * 템플릿 생성 예제
 */

// 클래스 참조
const AligoBrandClass = require('./aligo_brand_class');

// 클래스 로드
const brand = new AligoBrandClass();

(async () => {
    try {
        // TEXT - 타입 템플릿 생성
        const result = await brand.create_template({
            'userid': '알리고 계정 아이디',
            'apikey': '알리고 API 키',
            'senderkey': '카카오 채널 키',
            'template_type': 'TEXT',
            'adult': 'N',
            'template_name': '예시 템플릿 제목',
            'template_content': '예시 템플릿 내용',
            'template_button': [{
                'name': '서비스 바로가기1',
                'linkType': 'WL',
                'linkM': 'https://#{서비스버튼링크1}'
            }, {
                'name': '서비스 바로가기2',
                'linkType': 'WL',
                'linkM': 'https://#{서비스버튼링크2}'
            }],
            'template_coupon': {
                'title': 'type1',
                'description': '쿠폰 예시 텍스트',
                'linkM': 'http://#{쿠폰링크}',
                'linkI': 'alimtalk=coupon://#{쿠폰코드}',
                'linkA': 'alimtalk=coupon://#{쿠폰코드}'
            }
        });

        console.log('Content-Type: application/json');
        console.log(result);
    } catch (error) {
        console.error('Error:', error);
    }
})();

/*
// IMAGE - 타입 템플릿 생성
(async () => {
    try {
        const result = await brand.create_template({
            'userid': '알리고 계정 아이디',
            'apikey': '알리고 API 키',
            'senderkey': '카카오 채널 키',
            'template_type': 'IMAGE',
            'adult': 'N',
            'template_name': '예시 템플릿 제목',
            'template_content': '예시 템플릿 내용',
            'template_button': [{
                'name': '서비스 바로가기1',
                'linkType': 'WL',
                'linkM': 'https://#{서비스버튼링크1}'
            }, {
                'name': '서비스 바로가기2',
                'linkType': 'WL',
                'linkM': 'https://#{서비스버튼링크2}'
            }],
            'template_coupon': {
                'title': 'type1',
                'description': '쿠폰 예시 텍스트',
                'linkM': 'http://#{쿠폰링크}',
                'linkI': 'alimtalk=coupon://#{쿠폰코드}',
                'linkA': 'alimtalk=coupon://#{쿠폰코드}'
            },
            'image_link': 'https://smartsms.aligo.in/'
        }, {
            'image_upload': '800x400.jpg'
        });

        console.log('Content-Type: application/json');
        console.log(result);
    } catch (error) {
        console.error('Error:', error);
    }
})();
*/

/*
// WIDE - 타입 템플릿 생성
(async () => {
    try {
        const result = await brand.create_template({
            'userid': '알리고 계정 아이디',
            'apikey': '알리고 API 키',
            'senderkey': '카카오 채널 키',
            'template_type': 'WIDE',
            'adult': 'N',
            'template_name': '예시 와이드 템플릿 제목',
            'template_content': '예시 와이드 템플릿 내용',
            'template_button': [{
                'name': '바로가기1',
                'linkType': 'WL',
                'linkM': 'https://#{서비스버튼링크1}'
            }, {
                'name': '바로가기2',
                'linkType': 'WL',
                'linkM': 'https://#{서비스버튼링크2}'
            }],
            'template_coupon': {
                'title': 'type1',
                'description': '쿠폰 예시 텍스트',
                'linkM': 'https://#{쿠폰링크}',
                'linkI': 'alimtalk=coupon://#{쿠폰코드}',
                'linkA': 'alimtalk=coupon://#{쿠폰코드}'
            },
            'image_link': 'https://smartsms.aligo.in/'
        }, {
            'image_upload': '800x600.jpg'
        });

        console.log('Content-Type: application/json');
        console.log(result);
    } catch (error) {
        console.error('Error:', error);
    }
})();
*/

/*
// WIDE_ITEM_LIST - 타입 템플릿 생성
(async () => {
    try {
        const result = await brand.create_template({
            'userid': '알리고 계정 아이디',
            'apikey': '알리고 API 키',
            'senderkey': '카카오 채널 키',
            'template_type': 'WIDE_ITEM_LIST',
            'adult': 'N',
            'template_name': '예시 와이드 아이템 리스트 템플릿 제목',
            'template_header': '템플릿 헤더 테스트',
            'template_content': '예시 와이드 아이템 리스트 템플릿 내용',
            'main_wide_item': {
                'title': '아이템 제목',
                'linkM': 'https://#{메인테스트}',
                'linkP': 'https://#{메인테스트}'
            },
            'sub_wide_item1': {
                'title': '서브 아이템 1 제목',
                'linkM': 'https://#{테스트1}',
                'linkP': 'https://#{테스트1}'
            },
            'sub_wide_item2': {
                'title': '서브 아이템 2 제목',
                'linkM': 'https://#{테스트2}',
                'linkP': 'https://#{테스트2}'
            },
            'sub_wide_item3': {
                'title': '서브 아이템 3 제목',
                'linkM': 'https://#{테스트3}',
                'linkP': 'https://#{테스트3}'
            },
            'template_button': [{
                'name': '바로가기1',
                'linkType': 'WL',
                'linkM': 'https://#{서비스버튼링크1}'
            }, {
                'name': '바로가기2',
                'linkType': 'WL',
                'linkM': 'https://#{서비스버튼링크2}'
            }],
            'template_coupon': {
                'title': 'type1',
                'description': '쿠폰 예시 텍스트',
                'linkM': 'https://#{쿠폰링크}',
                'linkI': 'alimtalk=coupon://#{쿠폰코드}',
                'linkA': 'alimtalk=coupon://#{쿠폰코드}'
            }
        }, {
            'main_wide_item_image': '800x400.jpg',
            'sub_wide_item_image1': '800x800.jpg',
            'sub_wide_item_image2': '800x800.jpg',
            'sub_wide_item_image3': '800x800.jpg'
        });

        console.log('Content-Type: application/json');
        console.log(result);
    } catch (error) {
        console.error('Error:', error);
    }
})();
*/

/*
// CAROUSEL_FEED - 타입 템플릿 생성
(async () => {
    try {
        const result = await brand.create_template({
            'userid': '알리고 계정 아이디',
            'apikey': '알리고 API 키',
            'senderkey': '카카오 채널 키',
            'template_type': 'CAROUSEL_FEED',
            'adult': 'N',
            'template_name': '예시 캐러셀피드 템플릿 제목',
            'carousel_header': {
                'header': '예시 헤더',
                'content': '예시 컨텐츠',
                'linkM': 'https://#{헤더링크}',
                'linkP': 'https://#{헤더링크}'
            },
            'carousel_list': [{
                'header': '첫번째 피드 헤더',
                'content': '첫번째 피드 내용'
            }, {
                'header': '두번째 피드 헤더',
                'content': '두번째 피드 내용'
            }],
            'carousel_list_button1': [{
                'name': '피드버튼1-1',
                'linkType': 'WL',
                'linkM': 'https://#{피드버튼링크1-1}'
            }, {
                'name': '피드버튼1-2',
                'linkType': 'WL',
                'linkM': 'https://#{피드버튼링크1-2}'
            }],
            'carousel_list_button2': [{
                'name': '피드버튼2-1',
                'linkType': 'WL',
                'linkM': 'https://#{피드버튼링크2-1}'
            }, {
                'name': '피드버튼2-2',
                'linkType': 'WL',
                'linkM': 'https://#{피드버튼링크2-2}'
            }],
            'carousel_list_coupon1': {
                'title': 'type1',
                'description': '쿠폰 예시 텍스트',
                'linkM': 'http://#{쿠폰링크}',
                'linkI': 'alimtalk=coupon://#{쿠폰코드}',
                'linkA': 'alimtalk=coupon://#{쿠폰코드}'
            },
            'carousel_list_coupon2': {
                'title': 'type1',
                'description': '쿠폰 예시 텍스트',
                'linkM': 'http://#{쿠폰링크}',
                'linkI': 'alimtalk=coupon://#{쿠폰코드}',
                'linkA': 'alimtalk=coupon://#{쿠폰코드}'
            },
            'carousel_tail': {
                'linkM': 'https://smartsms.aligo.in/'
            }
        }, {
            'carousel_header_image': '800x400.jpg',
            'carousel_list_image1': '800x400.jpg',
            'carousel_list_image2': '800x400.jpg'
        });

        console.log('Content-Type: application/json');
        console.log(result);
    } catch (error) {
        console.error('Error:', error);
    }
})();
*/

/*
// PREMIUM_VIDEO - 타입 템플릿 생성
(async () => {
    try {
        const result = await brand.create_template({
            'userid': '알리고 계정 아이디',
            'apikey': '알리고 API 키',
            'senderkey': '카카오 채널 키',
            'template_type': 'PREMIUM_VIDEO',
            'adult': 'N',
            'template_name': '예시 프리미엄 비디오 템플릿 제목',
            'template_content': '예시 프리미엄 비디오 템플릿 내용',
            'template_button': [{
                'name': '바로가기1',
                'linkType': 'WL',
                'linkM': 'https://#{서비스버튼링크1}'
            }],
            'template_coupon': {
                'title': 'type1',
                'description': '쿠폰 예시 텍스트',
                'linkM': 'https://#{쿠폰링크}',
                'linkI': 'alimtalk=coupon://#{쿠폰코드}',
                'linkA': 'alimtalk=coupon://#{쿠폰코드}'
            },
            'template_video': '다음TV에 등록된 동영상 URL',
            'template_video_thumb': ''
        });

        console.log('Content-Type: application/json');
        console.log(result);
    } catch (error) {
        console.error('Error:', error);
    }
})();
*/

/*
// COMMERCE - 타입 템플릿 생성
(async () => {
    try {
        const result = await brand.create_template({
            'userid': '알리고 계정 아이디',
            'apikey': '알리고 API 키',
            'senderkey': '카카오 채널 키',
            'template_type': 'COMMERCE',
            'adult': 'N',
            'template_name': '커머스 템플릿 제목',
            'template_commerce': {
                'title': '상품제목',
                'regularPrice': '#{정상가격}',
                'discountPrice': '#{할인가격}',
                'discountRate': '#{할인율}',
                'discountFixed': '#{정액할인가격}'
            },
            'template_button': [{
                'name': '바로가기1',
                'linkType': 'WL',
                'linkM': 'https://#{서비스버튼링크1}'
            }, {
                'name': '바로가기2',
                'linkType': 'WL',
                'linkM': 'https://#{서비스버튼링크2}'
            }],
            'template_coupon': {
                'title': 'type1',
                'description': '쿠폰 예시 텍스트',
                'linkM': 'https://#{쿠폰링크}',
                'linkI': 'alimtalk=coupon://#{쿠폰코드}',
                'linkA': 'alimtalk=coupon://#{쿠폰코드}'
            },
            'image_link': 'https://smartsms.aligo.in/'
        }, {
            'image_upload': '800x400.jpg'
        });

        console.log('Content-Type: application/json');
        console.log(result);
    } catch (error) {
        console.error('Error:', error);
    }
})();
*/

/*
// CAROUSEL_COMMERCE - 타입 템플릿 생성
(async () => {
    try {
        const result = await brand.create_template({
            'userid': '알리고 계정 아이디',
            'apikey': '알리고 API 키',
            'senderkey': '카카오 채널 키',
            'template_type': 'CAROUSEL_COMMERCE',
            'adult': 'N',
            'template_name': '캐러셀 커머스 피드 템플릿 제목',
            'carousel_header': {
                'header': '예시 헤더',
                'content': '예시 컨텐츠',
                'linkM': 'https://#{헤더링크}',
                'linkP': 'https://#{헤더링크}'
            },
            'carousel_list': [{
                'additionalcontent': '커머스 부가정보 텍스트1'
            }, {
                'additionalcontent': '커머스 부가정보 텍스트2'
            }],
            'carousel_list_commerce1': {
                'title': '상품제목1',
                'regularPrice': '#{정상가격}',
                'discountPrice': '#{할인가격}',
                // 'discountRate': '#{할인율}', // discountRate 와 discountFixed 는 동시 사용이 허용되지 않습니다.
                'discountFixed': '#{정액할인가격}'
            },
            'carousel_list_commerce2': {
                'title': '상품제목2',
                'regularPrice': '#{정상가격}',
                'discountPrice': '#{할인가격}',
                'discountRate': '#{할인율}'
                // 'discountFixed': '#{정액할인가격}' // discountRate 와 discountFixed 는 동시 사용이 허용되지 않습니다.
            },
            'carousel_list_button1': [{
                'name': '피드버튼1-1',
                'linkType': 'WL',
                'linkM': 'https://#{버튼링크1-1}'
            }, {
                'name': '피드버튼1-2',
                'linkType': 'WL',
                'linkM': 'https://#{버튼링크1-2}'
            }],
            'carousel_list_button2': [{
                'name': '피드버튼2-1',
                'linkType': 'WL',
                'linkM': 'https://#{버튼링크2-1}'
            }, {
                'name': '피드버튼2-2',
                'linkType': 'WL',
                'linkM': 'https://#{버튼링크2-2}'
            }],
            'carousel_list_coupon1': {
                'title': 'type1',
                'description': '쿠폰 예시 텍스트',
                'linkM': 'http://#{쿠폰링크}',
                'linkI': 'alimtalk=coupon://#{쿠폰코드}',
                'linkA': 'alimtalk=coupon://#{쿠폰코드}'
            },
            'carousel_list_coupon2': {
                'title': 'type1',
                'description': '쿠폰 예시 텍스트',
                'linkM': 'http://#{쿠폰링크}',
                'linkI': 'alimtalk=coupon://#{쿠폰코드}',
                'linkA': 'alimtalk=coupon://#{쿠폰코드}'
            },
            'carousel_tail': {
                'linkM': 'https://smartsms.aligo.in/'
            }
        }, {
            'carousel_header_image': '800x400.jpg',
            'carousel_list_image1': '800x400.jpg',
            'carousel_list_image2': '800x400.jpg'
        });

        console.log('Content-Type: application/json');
        console.log(result);
    } catch (error) {
        console.error('Error:', error);
    }
})();
*/
